package com.example.juego_adivinar_numero_aleatorio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.juego_adivinar_numero_aleatorio.ui.theme.JuegoadivinarnumeroaleatorioTheme

class MainActivity : AppCompatActivity() {

    private lateinit var db: GameDbHelper
    private var randomNumber = 1
    private var score = 0

    private fun generateNewNumber() {
        randomNumber = (1..5).random()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = GameDbHelper(this)
        generateNewNumber()

        val input = findViewById<EditText>(R.id.inputGuess)
        val btn = findViewById<Button>(R.id.btnGuess)
        val message = findViewById<TextView>(R.id.textMessage)
        val attempts = findViewById<TextView>(R.id.textAttempts)

        attempts.text = "Intentos fallidos: ${db.getFails()}"

        btn.setOnClickListener {
            val guess = input.text.toString().toIntOrNull()
            if (guess == null || guess !in 1..5) {
                message.text = "Ingresa un número válido (1-5)"
                return@setOnClickListener
            }

            if (guess == randomNumber) {
                score += 10
                message.text = "¡Correcto! +10 puntos"
                db.resetFails()
            } else {
                val newFails = db.getFails() + 1
                db.setFails(newFails)
                if (newFails >= 5) {
                    score = 0
                    db.resetFails()
                    message.text = "Perdiste. Puntaje reiniciado."
                } else {
                    message.text = "Incorrecto. Sigue intentando."
                }
            }

            generateNewNumber()
            attempts.text = "Intentos fallidos: ${db.getFails()}"
            input.text.clear()
        }
    }
}