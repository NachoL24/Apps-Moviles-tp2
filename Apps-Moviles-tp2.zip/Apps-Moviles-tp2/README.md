# TP2 de Applicaciones móviles
En este repositorio se desarrollaran dos aplicaciones:
- aplicación que genere un número aleatorio entre 1 y 5.   
El usuario de la aplicación debe poder ingresar un valor numérico en un campo para 
adivinar dicho número. Si el usuario adivinó, se deberá incrementar en diez su puntaje. Si 
se equivoca 5 veces seguidas el jugador pierde el juego y vuelve su puntaje a cero. 
Además, la aplicación debe mostrar la mejor puntuación obtenida. Cada vez que el 
usuario ingrese a la aplicación, deberá mostrar, su puntuación actual y su máximo puntaje 
obtenido.
- aplicación que permita almacenar ciudades capitales del mundo.  De cada 
una se debe registrar: nombre del país donde se encuentra, nombre de la ciudad 
capital y población aproximada.   
La aplicación debe permitir:   
  1. Cargar una ciudad capital   
  2. Consultar una ciudad por su nombre   
  3. Borrar una ciudad ingresando su nombre   
  4. Borrar todas las ciudades de un país   
  5. Modificar la población de una ciudad.  

## Integrantes
- Eliseche, Martin
- Guerra, Lucio
- Lanzzavecchia Cespedes, Ignacio
- Wacelinka, Ariana
